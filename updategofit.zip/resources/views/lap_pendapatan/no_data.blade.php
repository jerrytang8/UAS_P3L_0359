<div class="card">
    <div class="card-header d-sm-flex d-block pb-0 border-0">
        <div class="mr-auto pr-3 mb-sm-0 mb-3">
            <h4 class="text-black fs-20">Pencarian Data Periode {{ $tahun }} Tidak Ditemukan</h4>

            <br>
        </div>

    </div>
</div>
